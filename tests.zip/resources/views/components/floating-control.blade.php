<div class="form-floating mb-3">
    {{-- عشان نظهر المحتوى --}}
    {{ $slot }}
    {{ $label }}
    {{-- <label for="{{ $name }}">{{ $placeholder }}</label> --}}
</div>