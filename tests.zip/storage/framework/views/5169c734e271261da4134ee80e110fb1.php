<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col items-center justify-center text-center">
        <h3 class="text-2xl mb-2"><?php echo e($leaveType->name); ?></h3>
        <div class="text-xl font-bold mb-4"><?php echo e($leaveType->description); ?></div>
        <div class="row">
            <div class="col">
                <div class="d-flex align-items-center">
                    <a href="<?php echo e(route('leaveTypes.edit', $leaveType->id)); ?>">
                        <i class="fa-solid fa-pencil"></i> Edit
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="d-flex align-items-center">
                    <form action="<?php echo e(route('leaveTypes.destroy', $leaveType->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="text-red-500" type="submit">
                            <i class="fa-solid fa-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?><?php /**PATH D:\www\LeaveRequests\resources\views/admin/leaveTypes/show.blade.php ENDPATH**/ ?>