<div class="card">
    <div class="h-100">

    <div class="card-body ">
        <h5 class="card-title"> <?php echo e($type->name); ?></h5>
        <p class="card-text"> <?php echo e($type->description); ?></p>
        <div class="d-flex justify-content-between align-items-center">
            <?php echo e($slot); ?>

        </div>
    </div>
    </div>
</div>
<?php /**PATH D:\www\LeaveRequests\resources\views/components/card.blade.php ENDPATH**/ ?>