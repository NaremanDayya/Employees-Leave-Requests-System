<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Leave Requests Systems</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
</head>

<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #008C62;" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="#page-top"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="..." /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars ms-1"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->type == 'administrator'): ?>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('employees.index')); ?>">Manage
                                    Employees</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('leaveTypes.index')); ?>">Manage Leave
                                    Types</a></li>
                            <li class="nav-item"><a class="nav-link"
                                    href="<?php echo e(route('employee.request.index', Auth::user()->id)); ?>">Manage
                                    Requests</a></li>
                            <li class="nav-item"><a class="nav-link"
                                    href="<?php echo e(route('administrator.notifications')); ?>">Notifications</a>
                            </li>
                        <?php elseif(Auth::user()->type == 'employee'): ?>
                            <li class="nav-item"><a class="nav-link"
                                    href="<?php echo e(route('employee.request.create', Auth::user()->id)); ?>">Submit Request</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('employee.requests')); ?>">Requests
                                    Status</a></li>
                            <li class="nav-item"><a class="nav-link"
                                    href="<?php echo e(route('employee.notifications', Auth::user()->id)); ?>">Notifications</a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php endif; ?>


                </ul>
            </div>
        </div>
    </nav>
    <main>
        <header class="masthead">
            <div class="container" style="background-color: beige">
                
                <?php echo e($slot); ?>

            </div>
        </header>
    </main>
    <footer class="footer py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 text-lg-start">GSG 2023</div>
                <div class="col-lg-4 my-3 my-lg-0">
                    <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i
                            class="fab fa-twitter"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Facebook"><i
                            class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i
                            class="fab fa-linkedin-in"></i></a>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                    <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                </div>
            </div>
        </div>
    </footer>
<?php /**PATH D:\www\LeaveRequests\resources\views/components/layout.blade.php ENDPATH**/ ?>